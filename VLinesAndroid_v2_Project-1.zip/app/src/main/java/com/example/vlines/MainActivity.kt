package com.example.vlines

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "V-Lines\n\nخطّان أحمران رفيعان على شكل V.\n\n• اسحب نهاية كل خط لتغيير طوله بشكل مستقل.\n• اسحب منتصف أحد الخطين لفتح أو تضييق الزاوية.\n• اسحب الشريط العلوي لتحريك الأداة.\n• زر × لإغلاقها.\n\nالنافذة صغيرة؛ اللمس خارجها يبقى متاحاً للعبة."
            textSize = 17f
        })
        layout.addView(Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        })
        layout.addView(Button(this).apply {
            text = "تشغيل V-Lines"
            setOnClickListener { startOverlay() }
        })
        setContentView(layout)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        startService(Intent(this, OverlayService::class.java))
        finish()
    }
}
