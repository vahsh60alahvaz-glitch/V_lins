package com.example.vlines

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        params = WindowManager.LayoutParams(
            (340 * density).toInt(),
            (390 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * density).toInt()
            y = (90 * density).toInt()
        }

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.TRANSPARENT)

        val bar = TextView(this).apply {
            text = "  V-Lines     اسحب هنا للتحريك       ×  "
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC292929.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 0, 8, 0)
        }
        val barHeight = (38 * density).toInt()
        val barParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, barHeight, Gravity.TOP
        )
        frame.addView(bar, barParams)

        bar.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (e.x > v.width - 42 * density) {
                            stopSelf()
                            return true
                        }
                        sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = ox + (e.rawX - sx).toInt()
                        params.y = oy + (e.rawY - sy).toInt()
                        try { wm.updateViewLayout(frame, params) } catch (_: Exception) {}
                        return true
                    }
                }
                return true
            }
        })

        val lines = VLinesView(this)
        val lineParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply { topMargin = barHeight }
        frame.addView(lines, lineParams)

        root = frame
        wm.addView(frame, params)
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
