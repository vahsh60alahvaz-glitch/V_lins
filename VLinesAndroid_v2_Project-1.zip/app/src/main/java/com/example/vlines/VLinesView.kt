package com.example.vlines

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class VLinesView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        strokeWidth = 1.6f * density
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    private var cx = 170f * density
    private var cy = 170f * density
    private var direction = Math.toRadians(-90.0)
    private var angle = Math.toRadians(58.0)
    private var len1 = 115f * density
    private var len2 = 90f * density
    private var mode = 0
    private var downX = 0f
    private var downY = 0f
    private var initialAngle = angle
    private var initialDirection = direction

    private fun endpoints(): Pair<Pair<Float, Float>, Pair<Float, Float>> {
        val a = direction - angle / 2
        val b = direction + angle / 2
        return Pair(
            Pair(cx + cos(a).toFloat() * len1, cy + sin(a).toFloat() * len1),
            Pair(cx + cos(b).toFloat() * len2, cy + sin(b).toFloat() * len2)
        )
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val (p1, p2) = endpoints()
        c.drawLine(cx, cy, p1.first, p1.second, linePaint)
        c.drawLine(cx, cy, p2.first, p2.second, linePaint)
        c.drawCircle(cx, cy, 2.5f * density, dotPaint)
        c.drawCircle(p1.first, p1.second, 4f * density, dotPaint)
        c.drawCircle(p2.first, p2.second, 4f * density, dotPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val (p1, p2) = endpoints()
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                val d1 = hypot(e.x-p1.first, e.y-p1.second)
                val d2 = hypot(e.x-p2.first, e.y-p2.second)
                val dPivot = hypot(e.x-cx, e.y-cy)
                mode = when {
                    d1 < 28*density -> 1
                    d2 < 28*density -> 2
                    dPivot < 30*density -> 3
                    else -> 4
                }
                initialAngle = angle
                initialDirection = direction
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> len1 = hypot(e.x-cx, e.y-cy).coerceIn(25f*density, 280f*density)
                    2 -> len2 = hypot(e.x-cx, e.y-cy).coerceIn(25f*density, 280f*density)
                    3 -> {
                        // Moving the pivot moves the whole V within the overlay.
                        cx = (cx + e.x - downX).coerceIn(25f*density, width-25f*density)
                        cy = (cy + e.y - downY).coerceIn(25f*density, height-25f*density)
                        downX = e.x; downY = e.y
                    }
                    4 -> {
                        // Drag near either arm to change the included angle symmetrically.
                        val delta = (e.x - downX) / (180f * density)
                        angle = (initialAngle + delta).coerceIn(Math.toRadians(8.0), Math.toRadians(165.0))
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { mode = 0; return true }
        }
        return true
    }
}
